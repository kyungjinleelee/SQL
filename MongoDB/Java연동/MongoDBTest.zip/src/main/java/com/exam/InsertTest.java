package com.exam;

import java.util.Arrays;
import java.util.List;

import org.bson.Document;
import org.bson.conversions.Bson;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;

public class InsertTest {

	public static void main(String[] args) {
		// db.collection.find()		
		MongoClient client = MongoClients.create("mongodb://localhost:27017");
		MongoDatabase db = client.getDatabase("tutorial");
		MongoCollection<Document> collection = db.getCollection("user");
		//###################
		// 가. 단일 문서 저장( insertOne(문서) )
		// db.user.insertOne(문서)
		Document d1 = new Document();
		 d1.append("_id", 8);
		 d1.append("username", "신사임당");
		 d1.append("age", 68);
		 d1.append("gender", "M");
		 
//		collection.insertOne(d1);
		 
		// 나. 멀티 문서 저장( insertMany(문서) )
		 Document x = new Document();
		 x.append("username", "신사임당");
		 x.append("age", 68);
		 x.append("gender", "M");
		 
		 Document x2 = new Document();
		 x2.append("username", "신사임당2");
		 x2.append("age", 66);
		 x2.append("gender", "F");
		 
		 List<Document> list = Arrays.asList(x, x2);
		 
		collection.insertMany(list);
		
		//###################
		
		// 4. 전체 조회 - db.user.find()
		MongoCursor<Document> cursor = collection.find().cursor();
			
				while(cursor.hasNext()) {
					Document doc = cursor.next();
					System.out.println(doc);
					System.out.println(doc.get("_id")+"\t"+ doc.getString("username"));
				}
	}

}
