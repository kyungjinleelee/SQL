package com.exam;

import org.bson.Document;
import org.bson.conversions.Bson;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Updates;

public class DeleteTest {

	public static void main(String[] args) {
		// db.collection.find()
		
		MongoClient client = MongoClients.create("mongodb://localhost:27017");
		MongoDatabase db = client.getDatabase("tutorial");
		MongoCollection<Document> collection = db.getCollection("user");
	
		//######################
		// 가. 단일 문서 삭제 ( deleteOne(필터) )
		// db.user.deleteOne({username:'정조'})
		collection.deleteOne(Filters.eq("username", "정조"));
		
		// 나. 멀티 문서 삭제 ( deleteMany(필터) )
		// db.user.deleteMany({age:{$lt:40}})
		collection.deleteMany(Filters.lt("age", 40));
		
		 //######################
		// 4. 전체 조회 - db.user.find()
		MongoCursor<Document> cursor = collection.find().cursor();
	
		while(cursor.hasNext()) {
			Document doc = cursor.next();
			System.out.println(doc);
			System.out.println(doc.get("_id")+"\t"+ doc.getString("username"));
		}
	}

}
