package com.exam;

import org.bson.Document;
import org.bson.conversions.Bson;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Updates;

public class UpdateTest {

	public static void main(String[] args) {
		// db.collection.find()
		
		MongoClient client = MongoClients.create("mongodb://localhost:27017");
		MongoDatabase db = client.getDatabase("tutorial");
		MongoCollection<Document> collection = db.getCollection("user");
	
		//######################
		// 가. 단일 문서 수정 ( updateOne(필터, 업데이트), $set 표현식)
		// 1) 업데이트 조건 한개. db.user.updateOne({username:'정조'}, {$set:{age:50}})
		Bson filter = Filters.eq("username", "정조");
		Bson update = Updates.set("age", 50);
		 collection.updateOne(filter, update); // username이 정조인 것을 찾아서 age를 50으로 set 하는 명령어
		
		// 2) 업데이트 조건 두개. db.user.updateOne({username:'정조'}, {$set:{age:70, gender:'f'}})
		Bson filter2 = Filters.eq("username", "정조");
		Bson update2 = Updates.combine(Updates.set("age", 70), Updates.set("gender", "f"));
		 collection.updateOne(filter2, update2);
		
		// 나. 멀티 문서 수정 ( updateMany(필터, 업데이트), $set 표현식)
		// db.user.updateMany({age:{$gt:40}}, {$set:{gender:'f'}} )
		collection.updateMany(Filters.gt("age", 40), Updates.set("gender", "m")); 
		 
		 //######################
		// 4. 전체 조회 - db.user.find()
		MongoCursor<Document> cursor = collection.find().cursor();
	
		while(cursor.hasNext()) {
			Document doc = cursor.next();
			System.out.println(doc);
			System.out.println(doc.get("_id")+"\t"+ doc.getString("username"));
		}
	}

}
